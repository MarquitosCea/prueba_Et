import numpy as np 
import os
import secundario as va 
matriz = np.empty((10,4), type(object))
l=0
while(True):
	os.system("cls")
	print("******* Casa Feliz ****** ")
	print("1. Comprar departamento ")
	print("2. Mostrar departamentos disponibles ")
	print("3. Ver listado de compradores ")
	print("4. Mostrar ganancias totales")
	print("5. Salir ")
	while(True):
		try:
			op=int(input("Ingrese la opción con la que desea proseguir: "))
			if(op>0 and op<6):
				break
			else:
				print("Ingrese una de las opciones mostradas anteriormente.")
		except ValueError:
				print("El número ingresado debe ser entero.")
	if(op==1):
		l=1 
		va.llenadoMatriz(matriz)
		print(matriz)
		input("presione enter para continuar")
		
	if(op==2):
		if(l==1):
			va.deptodisponibles(matriz)
			
		else:
			print("Debe llenar primero la matriz antes de hacer esta opción")
			input("Presione Enter para volver al menú. ")

	if(op==3):
		if(l==1):
			va.listacompradores
			
			
		else:
			print("Debe llenar primero la matriz antes de utilizar esta opción")
			input("Presione Enter para volver al menú.")

	if(op==4):
		if(l==1):
			va.ventastotales
			
		else:
			print("Debe llenar primero la matriz antes de utilizar esta opción")
			input("Presione Enter para volver al menú.")

	if(op==5):
		print("gracias por comprar su nuevo departamento con nosotros. ")
		print("Marcos Cea, 11/7/2023")
