import os 

def llenadoMatriz(matriz):
	for i in range(10):
		p=1
		os.system("cls")
		for j in range(4):
			if(i==0):
				os.system("cls")
				print("Ingrese el departamento que desea comprar: ",p)
				depa=""
				while(len(depa)<=0):
					depa=input("Ingrese uno de los departamentos dados, debe de ser un numero del 1 al 10 y una letra de la A a la D ")
					depa=""
					matriz[i][j]=depa
					p+=1

def deptodisponibles(matriz):
	for i in range(1):
		p=1
		os.system("pause")
		os.system("cls")

def listacompradores(matriz):
	for i in range(1):
		p=1
		os.system("pause")
		os.system("cls")

def ventastotales(matriz):
	for i in range(1):
		p=1
		os.system("pause")
		os.system("cls")